## Excerpt Name Generator

A random name generator for [Twilight Mirage](http://friendsatthetable.net/category/Twilight+Mirage)-esque excerpt names.

## Demo

[https://shannonkao.github.io/excerpt/](https://shannonkao.github.io/excerpt/)

Temporary
[https://excerpt.vercel.app](https://excerpt.vercel.app)

## Credit

Uses the [PoetryDB](https://github.com/thundercomb/poetrydb) API to grab random lines from poems.
